@extends('layouts.main')

@section('content')

    <div class="container">
        <div class="row">
            <div class="col-md-12 page-not-found">
                <h2>Page Not Found</h2>
                <p>
                    Sorry, the page you're looking for couldn't be found
                </p>
            </div>
        </div>
    </div>

@endsection
