<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <article class="post-item post-detail">
                    <?php if($post->image_url): ?>
                        <div class="post-item-image">
                            <img src="<?php echo e($post->image_url); ?>" alt="<?php echo e($post->title); ?>">
                        </div>
                    <?php endif; ?>

                    <div class="post-item-body">
                        <div class="padding-10">
                            <h1><?php echo e($post->title); ?></h1>

                            <div class="post-meta no-border">
                                <ul class="post-meta-group">
                                    <li><i class="fa fa-user"></i><a href="<?php echo e(route('author', $post->author->slug)); ?>"> <?php echo e($post->author->name); ?></a></li>
                                    <li><i class="fa fa-clock-o"></i><time> <?php echo e($post->date); ?></time></li>
                                    <li><i class="fa fa-folder"></i><a href="<?php echo e(route('category', $post->category->slug)); ?>"> <?php echo e($post->category->title); ?></a></li>
                                    <li><i class="fa fa-tag"></i><?php echo $post->tags_html; ?></li>
                                    <li><i class="fa fa-comments"></i><a href="#post-comments"><?php echo e($post->commentsNumber()); ?></a></li>
                                </ul>
                            </div>

                            <?php echo $post->body_html; ?>

                        </div>
                    </div>
                </article>

                <article class="post-author padding-10">
                    <div class="media">
                      <div class="media-left">
                        <?php $author = $post->author; ?>
                        <a href="<?php echo e(route('author', $author->slug)); ?>">
                          <img alt="<?php echo e($author->name); ?>" width="100" height="100" src="<?php echo e($author->gravatar()); ?>" class="media-object">
                        </a>
                      </div>
                      <div class="media-body">
                        <h4 class="media-heading"><a href="<?php echo e(route('author', $author->slug)); ?>"><?php echo e($author->name); ?></a></h4>
                        <div class="post-author-count">
                          <a href="<?php echo e(route('author', $author->slug)); ?>">
                              <i class="fa fa-clone"></i>
                              <?php $postCount = $author->posts()->published()->count() ?>
                              <?php echo e($postCount); ?> <?php echo e(str_plural('post', $postCount)); ?>

                          </a>
                        </div>
                        <?php echo $author->bio_html; ?>

                      </div>
                    </div>
                </article>

                <?php echo $__env->make('blog.comments', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>

            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>